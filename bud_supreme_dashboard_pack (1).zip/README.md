# bud_supreme

## Como rodar o Dashboard Flask (sorte_dashboard)

1. Instale as dependências:
   ```bash
   cd sorte_dashboard
   pip install -r requirements.txt
   ```

2. Configure as variáveis de ambiente (.env).

3. Rode o dashboard:
   ```bash
   python src/main.py
   ```

## Deploy no Railway

- Configure o Root Directory para `sorte_dashboard`.
- Use as variáveis de ambiente do seu .env.
- O Railway detecta o Procfile e roda automaticamente.
